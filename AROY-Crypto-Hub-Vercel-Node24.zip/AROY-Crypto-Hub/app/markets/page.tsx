 "use client";

import Link from "next/link";
import { Search, ArrowUpRight, TrendingUp, Activity, Sparkles } from "lucide-react";

const markets = [
  { symbol: "AROY", name: "AROY", price: "$0.0842", change: "+12.60%", volume: "$2.84M", cap: "$8.42M", hot: true },
  { symbol: "PEPE", name: "Pepe", price: "$0.0000092", change: "+6.18%", volume: "$38.7M", cap: "$3.88B" },
  { symbol: "DOGE", name: "Dogecoin", price: "$0.171", change: "+4.72%", volume: "$421M", cap: "$25.3B" },
  { symbol: "SOL", name: "Solana", price: "$154.20", change: "+5.47%", volume: "$1.16B", cap: "$72.9B" },
  { symbol: "ETH", name: "Ethereum", price: "$2,486", change: "+1.92%", volume: "$11.8B", cap: "$299B" },
  { symbol: "BTC", name: "Bitcoin", price: "$67,842", change: "+2.81%", volume: "$31.4B", cap: "$1.34T" },
];

export default function MarketsPage() {
  return (
    <main className="markets-page">
      <header className="markets-nav">
        <Link href="/" className="market-brand"><span className="market-logo">A</span> AROY</Link>
        <nav>
          <Link href="/">Home</Link>
          <Link href="/markets" className="active">Markets</Link>
          <a href="#coins">Coins</a>
          <a href="#trending">Trending</a>
        </nav>
        <Link href="/" className="market-launch">AROY Hub ↗</Link>
      </header>

      <section className="markets-hero">
        <div className="market-kicker"><span className="live-dot" /> LIVE MARKETS</div>
        <h1>Call where<br /><span>the market goes next.</span></h1>
        <p>Discover trending tokens, compare market activity, and follow the coins gaining momentum. Built for the AROY community.</p>
        <div className="market-actions">
          <a href="#coins" className="market-primary">Explore coins <ArrowUpRight size={16}/></a>
          <Link href="/" className="market-secondary">Open AROY Hub</Link>
        </div>
      </section>

      <section className="market-stats">
        <div><span>Total market cap</span><b>$2.41T</b><i>+3.24%</i></div>
        <div><span>24h volume</span><b>$86.7B</b><i>+8.12%</i></div>
        <div><span>Active markets</span><b>12,482</b><i>Live</i></div>
        <div><span>Trending now</span><b>AROY</b><i>+12.60%</i></div>
      </section>

      <section id="trending" className="market-section">
        <div className="section-top">
          <div><span className="section-kicker">DISCOVER</span><h2>Trending now</h2></div>
          <div className="search"><Search size={17}/><input placeholder="Search coins..." /></div>
        </div>
        <div className="trend-grid">
          {markets.slice(0, 3).map((m, i) => (
            <article className={"trend-card " + (m.hot ? "hot" : "")} key={m.symbol}>
              <div className="trend-top"><span className="token-icon">{m.symbol[0]}</span><span className="rank">#{i+1}</span></div>
              <h3>{m.symbol}</h3><p>{m.name}</p>
              <div className="trend-price">{m.price}</div>
              <div className="trend-change">{m.change}</div>
              <div className="mini-line"><span style={{width: `${72-i*13}%`}} /></div>
            </article>
          ))}
        </div>
      </section>

      <section id="coins" className="market-section">
        <div className="section-top">
          <div><span className="section-kicker">ALL COINS</span><h2>Live markets</h2></div>
          <div className="market-tabs"><button className="selected">All</button><button>Gainers</button><button>Volume</button></div>
        </div>
        <div className="coin-table">
          <div className="table-head"><span>Asset</span><span>Price</span><span>24h</span><span>Volume</span><span>Market cap</span><span /></div>
          {markets.map((m) => (
            <div className="coin-row" key={m.symbol}>
              <div className="asset-cell"><span className="token-icon small">{m.symbol[0]}</span><div><b>{m.symbol}</b><small>{m.name}</small></div></div>
              <strong>{m.price}</strong>
              <em>{m.change}</em>
              <span>{m.volume}</span>
              <span>{m.cap}</span>
              <button aria-label={`View ${m.symbol}`}><ArrowUpRight size={17}/></button>
            </div>
          ))}
        </div>
      </section>

      <section className="market-note">
        <Activity size={19}/>
        <div><b>Market data</b><span>This demo uses sample market values. Connect a production market-data provider before launch for live prices.</span></div>
        <Sparkles size={19}/>
      </section>

      <footer className="market-footer">© 2026 AROY Crypto Hub • Non-custodial market discovery interface.</footer>
    </main>
  );
}
