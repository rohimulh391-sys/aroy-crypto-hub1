 "use client";

import WalletButton from "./WalletButton";
import { ArrowLeftRight, BarChart3, ChevronRight, Fuel, Layers3, ShieldCheck, Sparkles, WalletCards } from "lucide-react";

const coins = [
  ["BTC", "Bitcoin", "$67,842", "+2.81%"],
  ["ETH", "Ethereum", "$2,486", "+1.92%"],
  ["SOL", "Solana", "$154.20", "+5.47%"],
  ["AROY", "AROY", "$0.0842", "+12.60%"],
];

const tools = [
  ["Swap", "Exchange tokens", ArrowLeftRight],
  ["Bridge", "Move assets", Layers3],
  ["Staking", "Earn on assets", Sparkles],
  ["Analytics", "Research wallets", BarChart3],
];

export default function Dashboard() {
  return (
    <div className="shell">
      <header className="nav">
        <a className="brand" href="#home">
          <span className="coin">A</span>
          <span>AROY <em>Crypto Hub</em></span>
        </a>

        <nav className="links">
          {["Home","Markets","Swap","Bridge","Staking","Portfolio","Analytics"].map((x) => (
            <a href={x === "Markets" ? "/markets" : "#" + x.toLowerCase()} key={x}>{x}</a>
          ))}
        </nav>

        <WalletButton />
      </header>

      <main className="wrap">
        <section className="hero" id="home">
          <div>
            <div className="eyebrow">AROY • WEB3 COMMAND CENTER</div>
            <h1>One hub.<br /><span>All of Web3.</span></h1>
            <p>Track markets, connect your wallet, explore assets and manage your crypto journey from one fast, modern dashboard.</p>
            <div className="actions">
              <WalletButton />
              <a className="secondary" href="#markets">Explore Markets <ChevronRight size={16} /></a>
            </div>
          </div>
          <div className="hero-orb">
            <div className="orb-ring"></div>
            <div className="orb-core">AROY</div>
            <div className="orb-caption">WEB3<br />HUB</div>
          </div>
        </section>

        <section className="stats">
          {[
            ["Market Cap", "$2.41T", "+3.24%"],
            ["24h Volume", "$86.7B", "+8.12%"],
            ["BTC Dominance", "56.8%", "+0.41%"],
            ["Network Gas", "18 Gwei", "Normal"],
          ].map(([a,b,c]) => (
            <div className="card stat" key={a}>
              <div className="label">{a}</div>
              <div className="value">{b}</div>
              <div className={c.startsWith("+") ? "up" : "muted"}>{c}</div>
            </div>
          ))}
        </section>

        <section className="grid" id="markets">
          <div className="card wide">
            <div className="cardhead">
              <div><div className="cardtitle">Market Overview</div><div className="muted">BTC / USD • 24H sample chart</div></div>
              <div className="up">+2.81%</div>
            </div>
            <div className="chart">
              <svg viewBox="0 0 900 285" preserveAspectRatio="none" aria-label="BTC chart">
                <defs><linearGradient id="g" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#57e6ff" stopOpacity=".28"/><stop offset="1" stopColor="#57e6ff" stopOpacity="0"/></linearGradient></defs>
                <path d="M0 230 C80 215 100 235 160 185 S240 210 290 150 S360 165 420 125 S500 145 560 95 S650 130 710 82 S800 110 900 35 L900 285 L0 285Z" fill="url(#g)"/>
                <path d="M0 230 C80 215 100 235 160 185 S240 210 290 150 S360 165 420 125 S500 145 560 95 S650 130 710 82 S800 110 900 35" fill="none" stroke="#57e6ff" strokeWidth="3"/>
              </svg>
              <div className="chart-badge">$67,842</div>
            </div>
          </div>

          <div className="card" id="trending">
            <div className="cardhead"><div><div className="cardtitle">Trending Assets</div><div className="muted">Market snapshot</div></div><BarChart3 size={18}/></div>
            <div className="watch">
              {coins.map((c) => (
                <div className="row" key={c[0]}>
                  <div className="coinname"><span className="dot">{c[0][0]}</span><div><b>{c[0]}</b><div className="muted">{c[1]}</div></div></div>
                  <span>{c[2]}</span><span className="up">{c[3]}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="grid" id="portfolio">
          <div className="card">
            <div className="cardhead"><div><div className="cardtitle">Your Portfolio</div><div className="muted">Connect your wallet for live balances</div></div><WalletCards size={19}/></div>
            <div className="portfolio">
              <div className="asset"><span>Total Balance</span><b>—</b></div>
              <div className="asset"><span>24h P/L</span><b>—</b></div>
            </div>
            <div style={{marginTop:14}}><WalletButton /></div>
          </div>

          <div className="card">
            <div className="cardhead"><div><div className="cardtitle">Security First</div><div className="muted">Non-custodial by design</div></div><ShieldCheck size={19}/></div>
            <p className="muted">AROY never asks for your seed phrase or private key. Review every transaction in your wallet before signing.</p>
            <div className="asset"><span>Wallet security</span><span className="up">Protected</span></div>
          </div>
        </section>

        <section className="card tools-section" id="swap">
          <div className="cardhead"><div><div className="cardtitle">Web3 Tools</div><div className="muted">Ready for real protocol integrations</div></div><Layers3 size={19}/></div>
          <div className="tools">
            {tools.map(([name, desc, Icon]) => (
              <div className="tool" key={name as string}>
                <Icon size={20}/><b>{name as string}</b><div className="muted">{desc as string}</div>
                <button className="secondary">Open {name as string}</button>
              </div>
            ))}
          </div>
        </section>

        <section className="network card" id="analytics">
          <div className="cardhead"><div><div className="cardtitle">Network Monitor</div><div className="muted">Provider status panel</div></div><Fuel size={19}/></div>
          <div className="row"><span>Ethereum Mainnet</span><span>18 Gwei</span><span className="up">Normal</span></div>
          <div className="row"><span>Sepolia Testnet</span><span>Test network</span><span className="up">Ready</span></div>
        </section>
      </main>

      <footer className="footer">© 2026 AROY Crypto Hub • Non-custodial Web3 interface.</footer>
    </div>
  );
}
