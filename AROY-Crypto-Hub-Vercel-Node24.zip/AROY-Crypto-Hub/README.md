# AROY Crypto Hub

A polished Next.js Web3 dashboard for the AROY brand.

## Run locally
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

## Real wallet connection
1. Copy `.env.example` to `.env.local`.
2. Add a WalletConnect/Reown project ID.
3. Optionally add your Mainnet and Sepolia RPC URLs.
4. Run the app and press **Connect Wallet**.

Supported by the starter:
- MetaMask / injected EIP-1193 wallets
- WalletConnect v2
- Ethereum Mainnet
- Sepolia
- Live connected native balance

The interface never asks for or stores seed phrases/private keys.

## Production note
The market numbers in the homepage are sample UI data. Before launch, connect a trusted market-data API and audited swap/bridge/staking protocols. Do not deploy unaudited smart contracts or expose secret API keys in `NEXT_PUBLIC_*` variables.


## Markets page
Visit `/markets` for the AROY live-markets style interface inspired by the reference you supplied. It is a market-discovery page and does not implement wagering or betting.


## Vercel
- This version pins Node.js to **24.x** for Vercel deployments.
- After uploading these files to GitHub, redeploy the project on Vercel.
