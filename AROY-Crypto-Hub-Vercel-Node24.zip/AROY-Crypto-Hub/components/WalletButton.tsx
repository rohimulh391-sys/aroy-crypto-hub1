 "use client";
import { useAccount, useBalance, useConnect, useDisconnect, useChainId } from "wagmi";
import { useState } from "react";

function short(a?: string) {
  return a ? `${a.slice(0,6)}…${a.slice(-4)}` : "";
}

export default function WalletButton() {
  const { address, isConnected } = useAccount();
  const { connect, connectors, isPending, error } = useConnect();
  const { disconnect } = useDisconnect();
  const chainId = useChainId();
  const { data: balance } = useBalance({ address });
  const [open, setOpen] = useState(false);

  if (isConnected) return <div style={{display:"flex",gap:8,alignItems:"center"}}>
    <button className="connect" onClick={()=>setOpen(v=>!v)}>{short(address)}</button>
    {open && <div className="wallet-pop">
      <div><b>{short(address)}</b></div>
      <div className="muted">{balance ? `${Number(balance.formatted).toFixed(4)} ${balance.symbol}` : "Loading balance…"}</div>
      <div className="muted">Chain ID: {chainId}</div>
      <button className="secondary" onClick={()=>disconnect()}>Disconnect</button>
    </div>}
  </div>;

  return <div>
    <button className="connect" onClick={()=>setOpen(v=>!v)}>{isPending ? "Connecting…" : "Connect Wallet"}</button>
    {open && <div className="wallet-pop">
      <b>Choose wallet</b>
      {connectors.map(c=><button className="wallet-choice" key={c.uid}
        onClick={()=>connect({connector:c})}>{c.name}</button>)}
      {!process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID &&
        <div className="muted">WalletConnect needs NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID.</div>}
      {error && <div style={{color:"#ff8e9e",fontSize:12}}>{error.message}</div>}
    </div>}
  </div>;
}
